
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 600

#jugador
playerOneColor = (255, 0, 0)
playerTwoColor = (0, 0, 255)

#Colores
WHITE = (255, 255 ,255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)

#Textos
titleColor = (0, 0, 0)
subtitleColor = (128, 0, 255)
lineColor = (0, 0, 0)

#Tablero
ANCHO = 500
DIMENSION = 3
TAMANO_CUADRO = 100